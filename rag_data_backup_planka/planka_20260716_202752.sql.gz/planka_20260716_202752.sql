--
-- PostgreSQL database dump
--

\restrict vAn3r3halAfJQnFpgEGG8C0fChVaVxZsDA2eT5OOI5dGHhpUybHzK81n6WUFjOa

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: next_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.next_id(OUT id bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
      DECLARE
        shard INT := 1;
        epoch BIGINT := 1567191600000;
        sequence BIGINT;
        milliseconds BIGINT;
      BEGIN
        SELECT nextval('next_id_seq') % 1024 INTO sequence;
        SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO milliseconds;
        id := (milliseconds - epoch) << 23;
        id := id | (shard << 10);
        id := id | (sequence);
      END;
    $$;


ALTER FUNCTION public.next_id(OUT id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.action (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    board_id bigint
);


ALTER TABLE public.action OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    creator_user_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: background_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.background_image (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    uploaded_file_id text NOT NULL,
    extension text NOT NULL,
    size bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.background_image OWNER TO postgres;

--
-- Name: base_custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.base_custom_field_group OWNER TO postgres;

--
-- Name: board; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    default_view text NOT NULL,
    default_card_type text NOT NULL,
    limit_card_types_to_default_one boolean NOT NULL,
    always_display_card_creator boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    expand_task_lists_by_default boolean NOT NULL,
    display_card_ages boolean NOT NULL
);


ALTER TABLE public.board OWNER TO postgres;

--
-- Name: board_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role text NOT NULL,
    can_comment boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_membership OWNER TO postgres;

--
-- Name: board_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.board_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.board_subscription OWNER TO postgres;

--
-- Name: card; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    list_id bigint NOT NULL,
    creator_user_id bigint,
    prev_list_id bigint,
    cover_attachment_id bigint,
    type text NOT NULL,
    "position" double precision,
    name text NOT NULL,
    description text,
    due_date timestamp without time zone,
    stopwatch jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    list_changed_at timestamp without time zone,
    comments_total integer NOT NULL,
    is_closed boolean NOT NULL,
    is_due_completed boolean
);


ALTER TABLE public.card OWNER TO postgres;

--
-- Name: card_label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_label (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    label_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_label OWNER TO postgres;

--
-- Name: card_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_membership (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_membership OWNER TO postgres;

--
-- Name: card_subscription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_subscription (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint NOT NULL,
    is_permanent boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.card_subscription OWNER TO postgres;

--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    user_id bigint,
    text text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.config (
    id bigint DEFAULT public.next_id() NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    smtp_host text,
    smtp_port integer,
    smtp_name text,
    smtp_secure boolean NOT NULL,
    smtp_tls_reject_unauthorized boolean NOT NULL,
    smtp_user text,
    smtp_password text,
    smtp_from text
);


ALTER TABLE public.config OWNER TO postgres;

--
-- Name: custom_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field (
    id bigint DEFAULT public.next_id() NOT NULL,
    base_custom_field_group_id bigint,
    custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field OWNER TO postgres;

--
-- Name: custom_field_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_group (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    card_id bigint,
    base_custom_field_group_id bigint,
    "position" double precision NOT NULL,
    name text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_group OWNER TO postgres;

--
-- Name: custom_field_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_field_value (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    custom_field_group_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.custom_field_value OWNER TO postgres;

--
-- Name: identity_provider_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_user (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    issuer text NOT NULL,
    sub text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.identity_provider_user OWNER TO postgres;

--
-- Name: internal_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.internal_config (
    id bigint DEFAULT public.next_id() NOT NULL,
    storage_limit text,
    active_users_limit integer,
    is_initialized boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.internal_config OWNER TO postgres;

--
-- Name: label; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.label (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text,
    color text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.label OWNER TO postgres;

--
-- Name: list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.list (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint NOT NULL,
    type text NOT NULL,
    "position" double precision,
    name text,
    color text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.list OWNER TO postgres;

--
-- Name: migration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migration OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migration_id_seq OWNER TO postgres;

--
-- Name: migration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_id_seq OWNED BY public.migration.id;


--
-- Name: migration_lock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migration_lock OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migration_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migration_lock_index_seq OWNER TO postgres;

--
-- Name: migration_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migration_lock_index_seq OWNED BY public.migration_lock.index;


--
-- Name: next_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.next_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.next_id_seq OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    creator_user_id bigint,
    board_id bigint NOT NULL,
    card_id bigint NOT NULL,
    comment_id bigint,
    action_id bigint,
    type text NOT NULL,
    data jsonb NOT NULL,
    is_read boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification_service (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint,
    board_id bigint,
    url text NOT NULL,
    format text NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.notification_service OWNER TO postgres;

--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id bigint DEFAULT public.next_id() NOT NULL,
    owner_project_manager_id bigint,
    background_image_id bigint,
    name text NOT NULL,
    description text,
    background_type text,
    background_gradient text,
    is_hidden boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_favorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_favorite (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_favorite OWNER TO postgres;

--
-- Name: project_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_manager (
    id bigint DEFAULT public.next_id() NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.project_manager OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    id bigint DEFAULT public.next_id() NOT NULL,
    user_id bigint NOT NULL,
    access_token text,
    http_only_token text,
    remote_address text NOT NULL,
    user_agent text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone,
    pending_token text
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: storage_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storage_usage (
    id bigint DEFAULT public.next_id() NOT NULL,
    total bigint NOT NULL,
    user_avatars bigint NOT NULL,
    background_images bigint NOT NULL,
    attachments bigint NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.storage_usage OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id bigint DEFAULT public.next_id() NOT NULL,
    task_list_id bigint NOT NULL,
    assignee_user_id bigint,
    "position" double precision NOT NULL,
    name text NOT NULL,
    is_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    linked_card_id bigint
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task_list (
    id bigint DEFAULT public.next_id() NOT NULL,
    card_id bigint NOT NULL,
    "position" double precision NOT NULL,
    name text NOT NULL,
    show_on_front_of_card boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    hide_completed_tasks boolean NOT NULL
);


ALTER TABLE public.task_list OWNER TO postgres;

--
-- Name: uploaded_file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uploaded_file (
    id text DEFAULT public.next_id() NOT NULL,
    references_total integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type text NOT NULL,
    mime_type text,
    size bigint NOT NULL
);


ALTER TABLE public.uploaded_file OWNER TO postgres;

--
-- Name: user_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_account (
    id bigint DEFAULT public.next_id() NOT NULL,
    email text NOT NULL,
    password text,
    role text NOT NULL,
    name text NOT NULL,
    username text,
    avatar jsonb,
    phone text,
    organization text,
    language text,
    subscribe_to_own_cards boolean NOT NULL,
    subscribe_to_card_when_commenting boolean NOT NULL,
    turn_off_recent_card_highlighting boolean NOT NULL,
    enable_favorites_by_default boolean NOT NULL,
    default_editor_mode text NOT NULL,
    default_home_view text NOT NULL,
    default_projects_order text NOT NULL,
    is_sso_user boolean NOT NULL,
    is_deactivated boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    password_changed_at timestamp without time zone,
    terms_signature text,
    terms_accepted_at timestamp without time zone,
    api_key_prefix text,
    api_key_hash text,
    api_key_created_at timestamp without time zone
);


ALTER TABLE public.user_account OWNER TO postgres;

--
-- Name: webhook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook (
    id bigint DEFAULT public.next_id() NOT NULL,
    board_id bigint,
    name text NOT NULL,
    url text NOT NULL,
    access_token text,
    events text[],
    excluded_events text[],
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.webhook OWNER TO postgres;

--
-- Name: migration id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration ALTER COLUMN id SET DEFAULT nextval('public.migration_id_seq'::regclass);


--
-- Name: migration_lock index; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock ALTER COLUMN index SET DEFAULT nextval('public.migration_lock_index_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.action (id, card_id, user_id, type, data, created_at, updated_at, board_id) FROM stdin;
\.


--
-- Data for Name: attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachment (id, card_id, creator_user_id, type, data, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: background_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.background_image (id, project_id, uploaded_file_id, extension, size, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: base_custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_custom_field_group (id, project_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board (id, project_id, "position", name, default_view, default_card_type, limit_card_types_to_default_one, always_display_card_creator, created_at, updated_at, expand_task_lists_by_default, display_card_ages) FROM stdin;
1820589514180003032	1813468952743904373	65536	Kanban Board	kanban	project	f	f	2026-07-16 17:26:22.546	\N	f	f
\.


--
-- Data for Name: board_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_membership (id, project_id, board_id, user_id, role, can_comment, created_at, updated_at) FROM stdin;
1820589514196780249	1813468952743904373	1820589514180003032	1812031286672360449	editor	\N	2026-07-16 17:26:22.55	\N
1820589559386211597	1813468952743904373	1820589514180003032	1820589521612309746	editor	\N	2026-07-16 17:26:27.936	\N
1820589559788864782	1813468952743904373	1820589514180003032	1820589523424249075	editor	\N	2026-07-16 17:26:27.985	\N
1820589560057300239	1813468952743904373	1820589514180003032	1820589525227799796	editor	\N	2026-07-16 17:26:28.017	\N
1820589560443176208	1813468952743904373	1820589514180003032	1820589526083437813	editor	\N	2026-07-16 17:26:28.063	\N
1820589561273648401	1813468952743904373	1820589514180003032	1820589526888744182	editor	\N	2026-07-16 17:26:28.161	\N
1820589561575638290	1813468952743904373	1820589514180003032	1820589527819879671	editor	\N	2026-07-16 17:26:28.198	\N
1820589561969902867	1813468952743904373	1820589514180003032	1820589528700683512	editor	\N	2026-07-16 17:26:28.245	\N
1820589562204783892	1813468952743904373	1820589514180003032	1820589529489212665	editor	\N	2026-07-16 17:26:28.273	\N
1820589562733266197	1813468952743904373	1820589514180003032	1820589530487457018	editor	\N	2026-07-16 17:26:28.335	\N
1820589563102364950	1813468952743904373	1820589514180003032	1820589532752381179	editor	\N	2026-07-16 17:26:28.38	\N
1820589563337245975	1813468952743904373	1820589514180003032	1820589533658350844	editor	\N	2026-07-16 17:26:28.408	\N
1820589563605681432	1813468952743904373	1820589514180003032	1820589534572709117	editor	\N	2026-07-16 17:26:28.439	\N
1820589563840562457	1813468952743904373	1820589514180003032	1820589536753747198	editor	\N	2026-07-16 17:26:28.467	\N
1820589564100609306	1813468952743904373	1820589514180003032	1820589538716681471	editor	\N	2026-07-16 17:26:28.499	\N
1820589564461319451	1813468952743904373	1820589514180003032	1820589539647816960	editor	\N	2026-07-16 17:26:28.54	\N
1820589565048522012	1813468952743904373	1820589514180003032	1820589540612506881	editor	\N	2026-07-16 17:26:28.611	\N
1820589565753165085	1813468952743904373	1820589514180003032	1820589541669471490	editor	\N	2026-07-16 17:26:28.695	\N
1820589566365533470	1813468952743904373	1820589514180003032	1820589542600606979	editor	\N	2026-07-16 17:26:28.768	\N
1820589566743020831	1813468952743904373	1820589514180003032	1820589545737946372	editor	\N	2026-07-16 17:26:28.813	\N
1820589567061787936	1813468952743904373	1820589514180003032	1820589549059835141	editor	\N	2026-07-16 17:26:28.852	\N
1820589567372166433	1813468952743904373	1820589514180003032	1820589550385235206	editor	\N	2026-07-16 17:26:28.888	\N
1820589567766431010	1813468952743904373	1820589514180003032	1820589551358313735	editor	\N	2026-07-16 17:26:28.935	\N
1820589568211027235	1813468952743904373	1820589514180003032	1820589552390112520	editor	\N	2026-07-16 17:26:28.988	\N
1820589568571737380	1813468952743904373	1820589514180003032	1820589553564517641	editor	\N	2026-07-16 17:26:29.032	\N
1820589568932447525	1813468952743904373	1820589514180003032	1820589556383089930	editor	\N	2026-07-16 17:26:29.074	\N
1820589569368655142	1813468952743904373	1820589514180003032	1820589557364557067	editor	\N	2026-07-16 17:26:29.126	\N
1820589569653867815	1813468952743904373	1820589514180003032	1820589558245360908	editor	\N	2026-07-16 17:26:29.16	\N
\.


--
-- Data for Name: board_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.board_subscription (id, board_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card (id, board_id, list_id, creator_user_id, prev_list_id, cover_attachment_id, type, "position", name, description, due_date, stopwatch, created_at, updated_at, list_changed_at, comments_total, is_closed, is_due_completed) FROM stdin;
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_label (id, card_id, label_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_membership (id, card_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: card_subscription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_subscription (id, card_id, user_id, is_permanent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (id, card_id, user_id, text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.config (id, created_at, updated_at, smtp_host, smtp_port, smtp_name, smtp_secure, smtp_tls_reject_unauthorized, smtp_user, smtp_password, smtp_from) FROM stdin;
1	2026-07-04 21:59:16.287	\N	\N	\N	\N	f	t	\N	\N	\N
\.


--
-- Data for Name: custom_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field (id, base_custom_field_group_id, custom_field_group_id, "position", name, show_on_front_of_card, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_group (id, board_id, card_id, base_custom_field_group_id, "position", name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_field_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_field_value (id, card_id, custom_field_group_id, custom_field_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: identity_provider_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_user (id, user_id, issuer, sub, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: internal_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.internal_config (id, storage_limit, active_users_limit, is_initialized, created_at, updated_at) FROM stdin;
1	\N	\N	t	2026-07-04 21:59:16.336	2026-07-04 22:03:20.997
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.label (id, board_id, "position", name, color, created_at, updated_at) FROM stdin;
1820589515723506913	1820589514180003032	65536	auth	navy-blue	2026-07-16 17:26:22.732	\N
1820589515983553762	1820589514180003032	131072	bug	berry-red	2026-07-16 17:26:22.762	\N
1820589516168103139	1820589514180003032	196608	feature	fresh-salad	2026-07-16 17:26:22.785	\N
1820589516344263908	1820589514180003032	262144	docs	antique-blue	2026-07-16 17:26:22.806	\N
1820589516512036069	1820589514180003032	327680	infra	dark-granite	2026-07-16 17:26:22.826	\N
1820589516746917094	1820589514180003032	393216	ops	gun-metal	2026-07-16 17:26:22.853	\N
1820589516939855079	1820589514180003032	458752	test	sweet-lilac	2026-07-16 17:26:22.876	\N
1820589517099238632	1820589514180003032	524288	research	turquoise-sea	2026-07-16 17:26:22.896	\N
1820589517308953833	1820589514180003032	589824	urgent	piggy-red	2026-07-16 17:26:22.92	\N
1820589517560612074	1820589514180003032	655360	high	pumpkin-orange	2026-07-16 17:26:22.95	\N
1820589517778715883	1820589514180003032	720896	medium	egg-yellow	2026-07-16 17:26:22.977	\N
1820589517996819692	1820589514180003032	786432	low	muddy-grey	2026-07-16 17:26:23.003	\N
1820589518240089325	1820589514180003032	851968	architect	lilac-eyes	2026-07-16 17:26:23.032	\N
1820589518491747566	1820589514180003032	917504	developer	summer-sky	2026-07-16 17:26:23.061	\N
1820589518785348847	1820589514180003032	983040	reviewer	autumn-leafs	2026-07-16 17:26:23.096	\N
1820589519037007088	1820589514180003032	1048576	tester	morning-sky	2026-07-16 17:26:23.127	\N
1820589519322219761	1820589514180003032	1114112	researcher	sugar-plum	2026-07-16 17:26:23.161	\N
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.list (id, board_id, type, "position", name, color, created_at, updated_at) FROM stdin;
1820589514221946074	1820589514180003032	archive	\N	\N	\N	2026-07-16 17:26:22.553	\N
1820589514221946075	1820589514180003032	trash	\N	\N	\N	2026-07-16 17:26:22.553	\N
1820589514708485340	1820589514180003032	active	65536	backlog	\N	2026-07-16 17:26:22.611	\N
1820589514842703069	1820589514180003032	active	131072	todo	\N	2026-07-16 17:26:22.627	\N
1820589514976920798	1820589514180003032	active	196608	in_progress	\N	2026-07-16 17:26:22.643	\N
1820589515119527135	1820589514180003032	active	262144	review	\N	2026-07-16 17:26:22.66	\N
1820589515270522080	1820589514180003032	active	327680	done	\N	2026-07-16 17:26:22.678	\N
\.


--
-- Data for Name: migration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration (id, name, batch, migration_time) FROM stdin;
1	20250228000022_version_2.js	1	2026-07-04 21:59:16.258+00
2	20250522151122_add_board_activity_log.js	1	2026-07-04 21:59:16.262+00
3	20250523131647_add_comments_counter.js	1	2026-07-04 21:59:16.265+00
4	20250603102521_canonicalize_locale_codes.js	1	2026-07-04 21:59:16.266+00
5	20250703122452_move_webhooks_configuration_from_environment_variable_to_ui.js	1	2026-07-04 21:59:16.272+00
6	20250708200908_persist_closed_state_per_card.js	1	2026-07-04 21:59:16.274+00
7	20250709160208_add_ability_to_link_tasks_to_cards.js	1	2026-07-04 21:59:16.277+00
8	20250721132312_add_ability_to_hide_completed_tasks.js	1	2026-07-04 21:59:16.279+00
9	20250728105713_add_legal_requirements.js	1	2026-07-04 21:59:16.289+00
10	20250820144730_track_storage_usage.js	1	2026-07-04 21:59:16.317+00
11	20250905101408_restore_toggleable_due_dates.js	1	2026-07-04 21:59:16.319+00
12	20250905205438_add_board_setting_to_expand_task_lists_by_default.js	1	2026-07-04 21:59:16.322+00
13	20250917123048_add_ability_to_configure_smtp_via_ui.js	1	2026-07-04 21:59:16.329+00
14	20251105104948_add_api_key_authentication.js	1	2026-07-04 21:59:16.332+00
15	20251121231641_rename_gin_indexes.js	1	2026-07-04 21:59:16.332+00
16	20260122093047_add_internal_runtime_configuration.js	1	2026-07-04 21:59:16.337+00
17	20260312000000_add_ability_to_display_card_ages.js	1	2026-07-04 21:59:16.338+00
\.


--
-- Data for Name: migration_lock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, user_id, creator_user_id, board_id, card_id, comment_id, action_id, type, data, is_read, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification_service (id, user_id, board_id, url, format, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, owner_project_manager_id, background_image_id, name, description, background_type, background_gradient, is_hidden, created_at, updated_at) FROM stdin;
1813468952743904373	\N	\N	Planka Orchestrator	Planka Multi-Agent Orchestrator	\N	\N	f	2026-07-06 21:39:05.477	\N
\.


--
-- Data for Name: project_favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_favorite (id, project_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_manager (id, project_id, user_id, created_at, updated_at) FROM stdin;
1813468952760681590	1813468952743904373	1812031286672360449	2026-07-06 21:39:05.48	\N
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (id, user_id, access_token, http_only_token, remote_address, user_agent, created_at, updated_at, deleted_at, pending_token) FROM stdin;
1812031550947066882	1812031286672360449	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjA2NzZlZDQxLWUxNWItNGFhZS1hYWFkLTMwN2QxOTE2ZTY2ZCJ9.eyJpYXQiOjE3ODMyMDI2MDAsImV4cCI6MTgxNDczODYwMCwic3ViIjoiMTgxMjAzMTI4NjY3MjM2MDQ0OSJ9.tyHx_HhIPlNMsvJZvu7C5NXjnh0uLQp9TgOi3t--6Vk	357e73c2-eb6f-41bd-bea0-ccf580d2c3aa	172.24.0.1	Mozilla/5.0 (X11; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0	2026-07-04 22:03:13.829	2026-07-04 22:03:21.001	\N	\N
\.


--
-- Data for Name: storage_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storage_usage (id, total, user_avatars, background_images, attachments, created_at, updated_at) FROM stdin;
1	0	0	0	0	2026-07-04 21:59:16.053472	\N
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, task_list_id, assignee_user_id, "position", name, is_completed, created_at, updated_at, linked_card_id) FROM stdin;
\.


--
-- Data for Name: task_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task_list (id, card_id, "position", name, show_on_front_of_card, created_at, updated_at, hide_completed_tasks) FROM stdin;
\.


--
-- Data for Name: uploaded_file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uploaded_file (id, references_total, created_at, updated_at, type, mime_type, size) FROM stdin;
\.


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_account (id, email, password, role, name, username, avatar, phone, organization, language, subscribe_to_own_cards, subscribe_to_card_when_commenting, turn_off_recent_card_highlighting, enable_favorites_by_default, default_editor_mode, default_home_view, default_projects_order, is_sso_user, is_deactivated, created_at, updated_at, password_changed_at, terms_signature, terms_accepted_at, api_key_prefix, api_key_hash, api_key_created_at) FROM stdin;
1820589542600606979	tester_6@planka-orchestrator.local	$2b$10$V9duhCgWPC5t/8nu5iNJ2.CAilqMGn5jWxrPpqUykvyQodLnX0Zbq	boardUser	Tester 6	tester_6	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:25.935	\N	\N	\N	\N	\N	\N	\N
1812031286672360449	admin@planka.local	$2b$10$o7DgV8KQIXxGQGPu0nvfceJymTnSRxVqvKa41EPC1/64KnHUoYtfC	admin	Admin	admin	\N	\N	\N	en-US	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-04 22:02:42.326	2026-07-04 22:10:51.7	\N	03f07fa4887405919f0a569871c5bed69e5fc2e7045b186145dbd8ca09c2351a	2026-07-04 22:03:20.972	yUbJjL3O	829c0f0f46ffeaecf27c05bedc0ae64f62e6ecfeac7c4f9bd165d3c0e03fbf2f	2026-07-04 22:10:51.697
1820589521612309746	developer_1@planka-orchestrator.local	$2b$10$L8rA6RYDXVId4EZkE6ezC.Pd2FF8EC1stdDj0EPQ7/z1C5vuBRVe2	boardUser	Developer 1	developer_1	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:23.433	\N	\N	\N	\N	\N	\N	\N
1820589523424249075	developer_2@planka-orchestrator.local	$2b$10$Va0iahKD5qWE5XWf8zOqq.WQZjhoNx92PqBlHJxM/PpxixM5iuv5G	boardUser	Developer 2	developer_2	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:23.649	\N	\N	\N	\N	\N	\N	\N
1820589525227799796	developer_3@planka-orchestrator.local	$2b$10$/kcqSCc6IYh2L.7Eh38e4uuESUiMt5DwjAGe/8r69QNQOVN8fYIXO	boardUser	Developer 3	developer_3	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:23.864	\N	\N	\N	\N	\N	\N	\N
1820589545737946372	reviewer_1@planka-orchestrator.local	$2b$10$/jFaoygwcxss7cvutmE3peWxDJwBzo.LXAuCxSDGVAlniHAlsdGfW	boardUser	Reviewer 1	reviewer_1	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:26.303	\N	\N	\N	\N	\N	\N	\N
1820589526083437813	developer_4@planka-orchestrator.local	$2b$10$fyDmvBQDzhCxfwgY/jRNm.dAaG5IbaBoUsm3PzD/pwbpSkQcj0/3K	boardUser	Developer 4	developer_4	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:23.966	\N	\N	\N	\N	\N	\N	\N
1820589526888744182	developer_5@planka-orchestrator.local	$2b$10$.ZoZ1K4gJCIqbiCAe7YlmednTNrqcjMi/WvDgXj9kiqLG75U1yfFu	boardUser	Developer 5	developer_5	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.061	\N	\N	\N	\N	\N	\N	\N
1820589527819879671	developer_6@planka-orchestrator.local	$2b$10$6ET1LMfX/pELc47D3BdNLOEZJb6Ow1rHkza22z.PgTT6/PMeTlAAy	boardUser	Developer 6	developer_6	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.174	\N	\N	\N	\N	\N	\N	\N
1820589528700683512	developer_7@planka-orchestrator.local	$2b$10$CKwwOOCAwWj/aRxdBOm9xeDFwIfIgfI6s95989lrPp2oveCDCxsHa	boardUser	Developer 7	developer_7	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.277	\N	\N	\N	\N	\N	\N	\N
1820589529489212665	developer_8@planka-orchestrator.local	$2b$10$gcUQz57qzZ.C7fbl7zgGMOQZ5kqd9bNIpIzlHN1D6vxCf8aE/LOiq	boardUser	Developer 8	developer_8	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.372	\N	\N	\N	\N	\N	\N	\N
1820589530487457018	developer_9@planka-orchestrator.local	$2b$10$XJhzBxfdWkxaoXa3ox25bOylMMWFdoCeQ6fqr87MLFIjV3VhR2B8y	boardUser	Developer 9	developer_9	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.488	\N	\N	\N	\N	\N	\N	\N
1820589532752381179	architect_1@planka-orchestrator.local	$2b$10$2m.9B.TkbVvKmtsF1MYMJ.xUA4bWZJ78zTVUhQ70OpuY9gQqkwCe6	boardUser	Architect 1	architect_1	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.761	\N	\N	\N	\N	\N	\N	\N
1820589533658350844	architect_2@planka-orchestrator.local	$2b$10$6C09tWECYkF4isuXTtVLzuVEJu0FxdKGqdV7jPgrMdYZMffXI8YDy	boardUser	Architect 2	architect_2	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.868	\N	\N	\N	\N	\N	\N	\N
1820589534572709117	architect_3@planka-orchestrator.local	$2b$10$66VY9qce8a.f3J9GVMI6/e7RMeIAIoD3H/prgS4RGNX5.Ub4UogyO	boardUser	Architect 3	architect_3	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:24.978	\N	\N	\N	\N	\N	\N	\N
1820589536753747198	tester_1@planka-orchestrator.local	$2b$10$Gd/SsinS62J/W8RUvnv.9eqnDXR5MzzeGf1qhz.Mdo7kmMvUR4ddK	boardUser	Tester 1	tester_1	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:25.237	\N	\N	\N	\N	\N	\N	\N
1820589538716681471	tester_2@planka-orchestrator.local	$2b$10$D//0DK.oybqnMO.J1nGLXOOlxu1jdroyAVc4nypxX/9TdctKyh.XS	boardUser	Tester 2	tester_2	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:25.471	\N	\N	\N	\N	\N	\N	\N
1820589539647816960	tester_3@planka-orchestrator.local	$2b$10$LuBPL5Hh9OZxFPNjP78a.OyOgMjV.8E9sclJr5uB4qC9eyMhGALOm	boardUser	Tester 3	tester_3	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:25.583	\N	\N	\N	\N	\N	\N	\N
1820589540612506881	tester_4@planka-orchestrator.local	$2b$10$JfYY3ILOhlBzSe2wTIPRQukPp9zzZd5.8bt9rgpDD6XfjNRkOF4CS	boardUser	Tester 4	tester_4	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:25.698	\N	\N	\N	\N	\N	\N	\N
1820589541669471490	tester_5@planka-orchestrator.local	$2b$10$y76ft8Mz6h6ivcJokyPn4.CZxrnU.Q/sWZ4aOakQaNdVE/gCfmNh.	boardUser	Tester 5	tester_5	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:25.825	\N	\N	\N	\N	\N	\N	\N
1820589549059835141	reviewer_2@planka-orchestrator.local	$2b$10$P6S8gu0a1cH./vxJQ8Oh3.LiEhLb8dEBNWobeDs7zQbY8VclR5UJC	boardUser	Reviewer 2	reviewer_2	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:26.702	\N	\N	\N	\N	\N	\N	\N
1820589550385235206	reviewer_3@planka-orchestrator.local	$2b$10$QJRUkbxQpMrsxz4pMXHWl.IQOtmMbdPEXrqysg64c2.LDT3PqEgi.	boardUser	Reviewer 3	reviewer_3	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:26.86	\N	\N	\N	\N	\N	\N	\N
1820589551358313735	reviewer_4@planka-orchestrator.local	$2b$10$3Jzua8XF..0viJdATiR0veRgWdpxm25KSX3mITMhf.qLmjuDY57q2	boardUser	Reviewer 4	reviewer_4	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:26.979	\N	\N	\N	\N	\N	\N	\N
1820589552390112520	reviewer_5@planka-orchestrator.local	$2b$10$sSDqoOQOgAu.h47PNOqi..ySqs7FzfRNoNDhyeVeSnuY9TcNXrxkO	boardUser	Reviewer 5	reviewer_5	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:27.101	\N	\N	\N	\N	\N	\N	\N
1820589553564517641	reviewer_6@planka-orchestrator.local	$2b$10$0pQsHfz1rXW0DRh9P0GuXuM6pOe/C5xg0d/lMcAkNKE10/QKnNRtG	boardUser	Reviewer 6	reviewer_6	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:27.235	\N	\N	\N	\N	\N	\N	\N
1820589556383089930	researcher_1@planka-orchestrator.local	$2b$10$meHUlXnWq9h4OQWnuP3h9ei25EsjWts8KLW7tU4OUxTUO9F2//cXa	boardUser	Researcher 1	researcher_1	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:27.577	\N	\N	\N	\N	\N	\N	\N
1820589557364557067	researcher_2@planka-orchestrator.local	$2b$10$MObdsd8FZbk7u6MPHOiy7.mhEpCnLQ.6Bz0o2ukaYJKDVGYOtLqwS	boardUser	Researcher 2	researcher_2	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:27.695	\N	\N	\N	\N	\N	\N	\N
1820589558245360908	researcher_3@planka-orchestrator.local	$2b$10$kcHX7bZ7LPSG9HkD04LbhO7qjWFJEvbat1IXKcKvwmi3P/m1mW1xe	boardUser	Researcher 3	researcher_3	\N	\N	\N	\N	f	t	f	t	wysiwyg	groupedProjects	byDefault	f	f	2026-07-16 17:26:27.8	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: webhook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook (id, board_id, name, url, access_token, events, excluded_events, created_at, updated_at) FROM stdin;
1812046362259227673	\N	orchestrator	http://172.24.0.1:8090/webhook	026a664c0fc5f1346f8ccdb5ab36ab253a7cf3f51712a757	{cardCreate,cardUpdate,commentCreate}	\N	2026-07-04 22:32:39.475	2026-07-04 22:33:10.326
1813471576759207052	\N	Planka Orchestrator	http://172.24.0.1:8090/webhook	026a664c0fc5f1346f8ccdb5ab36ab253a7cf3f51712a757	\N	\N	2026-07-06 21:44:18.285	2026-07-16 17:26:29.204
\.


--
-- Name: migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_id_seq', 17, true);


--
-- Name: migration_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migration_lock_index_seq', 1, true);


--
-- Name: next_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.next_id_seq', 2343, true);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: background_image background_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.background_image
    ADD CONSTRAINT background_image_pkey PRIMARY KEY (id);


--
-- Name: base_custom_field_group base_custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_custom_field_group
    ADD CONSTRAINT base_custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: board_membership board_membership_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_membership board_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_membership
    ADD CONSTRAINT board_membership_pkey PRIMARY KEY (id);


--
-- Name: board board_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: board_subscription board_subscription_board_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_board_id_user_id_unique UNIQUE (board_id, user_id);


--
-- Name: board_subscription board_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.board_subscription
    ADD CONSTRAINT board_subscription_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_card_id_label_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_card_id_label_id_unique UNIQUE (card_id, label_id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: card_membership card_membership_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_membership card_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_membership
    ADD CONSTRAINT card_membership_pkey PRIMARY KEY (id);


--
-- Name: card card_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card
    ADD CONSTRAINT card_pkey PRIMARY KEY (id);


--
-- Name: card_subscription card_subscription_card_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_card_id_user_id_unique UNIQUE (card_id, user_id);


--
-- Name: card_subscription card_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_subscription
    ADD CONSTRAINT card_subscription_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: custom_field_group custom_field_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_group
    ADD CONSTRAINT custom_field_group_pkey PRIMARY KEY (id);


--
-- Name: custom_field custom_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field
    ADD CONSTRAINT custom_field_pkey PRIMARY KEY (id);


--
-- Name: custom_field_value custom_field_value_card_id_custom_field_group_id_custom_field_i; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_card_id_custom_field_group_id_custom_field_i UNIQUE (card_id, custom_field_group_id, custom_field_id);


--
-- Name: custom_field_value custom_field_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_field_value
    ADD CONSTRAINT custom_field_value_pkey PRIMARY KEY (id);


--
-- Name: identity_provider_user identity_provider_user_issuer_sub_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_issuer_sub_unique UNIQUE (issuer, sub);


--
-- Name: identity_provider_user identity_provider_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_user
    ADD CONSTRAINT identity_provider_user_pkey PRIMARY KEY (id);


--
-- Name: internal_config internal_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.internal_config
    ADD CONSTRAINT internal_config_pkey PRIMARY KEY (id);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: migration_lock migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_lock
    ADD CONSTRAINT migration_lock_pkey PRIMARY KEY (index);


--
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_service notification_service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification_service
    ADD CONSTRAINT notification_service_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_pkey PRIMARY KEY (id);


--
-- Name: project_favorite project_favorite_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_favorite
    ADD CONSTRAINT project_favorite_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project_manager project_manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_pkey PRIMARY KEY (id);


--
-- Name: project_manager project_manager_project_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_manager
    ADD CONSTRAINT project_manager_project_id_user_id_unique UNIQUE (project_id, user_id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: session session_access_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_access_token_unique UNIQUE (access_token);


--
-- Name: session session_pending_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pending_token_unique UNIQUE (pending_token);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: storage_usage storage_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_usage
    ADD CONSTRAINT storage_usage_pkey PRIMARY KEY (id);


--
-- Name: task_list task_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task_list
    ADD CONSTRAINT task_list_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: uploaded_file uploaded_file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uploaded_file
    ADD CONSTRAINT uploaded_file_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_api_key_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_api_key_hash_unique UNIQUE (api_key_hash);


--
-- Name: user_account user_account_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_email_unique UNIQUE (email);


--
-- Name: user_account user_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_pkey PRIMARY KEY (id);


--
-- Name: user_account user_account_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_account
    ADD CONSTRAINT user_account_username_unique EXCLUDE USING btree (username WITH =) WHERE ((username IS NOT NULL));


--
-- Name: webhook webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook
    ADD CONSTRAINT webhook_pkey PRIMARY KEY (id);


--
-- Name: action_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_board_id_index ON public.action USING btree (board_id);


--
-- Name: action_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_card_id_index ON public.action USING btree (card_id);


--
-- Name: action_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX action_user_id_index ON public.action USING btree (user_id);


--
-- Name: attachment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_card_id_index ON public.attachment USING btree (card_id);


--
-- Name: attachment_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachment_creator_user_id_index ON public.attachment USING btree (creator_user_id);


--
-- Name: background_image_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX background_image_project_id_index ON public.background_image USING btree (project_id);


--
-- Name: base_custom_field_group_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX base_custom_field_group_project_id_index ON public.base_custom_field_group USING btree (project_id);


--
-- Name: board_membership_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_project_id_index ON public.board_membership USING btree (project_id);


--
-- Name: board_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_membership_user_id_index ON public.board_membership USING btree (user_id);


--
-- Name: board_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_position_index ON public.board USING btree ("position");


--
-- Name: board_project_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_project_id_index ON public.board USING btree (project_id);


--
-- Name: board_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX board_subscription_user_id_index ON public.board_subscription USING btree (user_id);


--
-- Name: card_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_board_id_index ON public.card USING btree (board_id);


--
-- Name: card_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_creator_user_id_index ON public.card USING btree (creator_user_id);


--
-- Name: card_description_gin_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_description_gin_index ON public.card USING gin (description public.gin_trgm_ops);


--
-- Name: card_label_label_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_label_label_id_index ON public.card_label USING btree (label_id);


--
-- Name: card_list_changed_at_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_changed_at_index ON public.card USING btree (list_changed_at);


--
-- Name: card_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_list_id_index ON public.card USING btree (list_id);


--
-- Name: card_membership_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_membership_user_id_index ON public.card_membership USING btree (user_id);


--
-- Name: card_name_gin_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_name_gin_index ON public.card USING gin (name public.gin_trgm_ops);


--
-- Name: card_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_position_index ON public.card USING btree ("position");


--
-- Name: card_subscription_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX card_subscription_user_id_index ON public.card_subscription USING btree (user_id);


--
-- Name: comment_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_card_id_index ON public.comment USING btree (card_id);


--
-- Name: comment_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comment_user_id_index ON public.comment USING btree (user_id);


--
-- Name: custom_field_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_base_custom_field_group_id_index ON public.custom_field USING btree (base_custom_field_group_id);


--
-- Name: custom_field_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_custom_field_group_id_index ON public.custom_field USING btree (custom_field_group_id);


--
-- Name: custom_field_group_base_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_base_custom_field_group_id_index ON public.custom_field_group USING btree (base_custom_field_group_id);


--
-- Name: custom_field_group_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_board_id_index ON public.custom_field_group USING btree (board_id);


--
-- Name: custom_field_group_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_card_id_index ON public.custom_field_group USING btree (card_id);


--
-- Name: custom_field_group_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_group_position_index ON public.custom_field_group USING btree ("position");


--
-- Name: custom_field_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_position_index ON public.custom_field USING btree ("position");


--
-- Name: custom_field_value_custom_field_group_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_group_id_index ON public.custom_field_value USING btree (custom_field_group_id);


--
-- Name: custom_field_value_custom_field_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX custom_field_value_custom_field_id_index ON public.custom_field_value USING btree (custom_field_id);


--
-- Name: identity_provider_user_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX identity_provider_user_user_id_index ON public.identity_provider_user USING btree (user_id);


--
-- Name: label_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_board_id_index ON public.label USING btree (board_id);


--
-- Name: label_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX label_position_index ON public.label USING btree ("position");


--
-- Name: list_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_board_id_index ON public.list USING btree (board_id);


--
-- Name: list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_position_index ON public.list USING btree ("position");


--
-- Name: list_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX list_type_index ON public.list USING btree (type);


--
-- Name: notification_action_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_action_id_index ON public.notification USING btree (action_id);


--
-- Name: notification_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_card_id_index ON public.notification USING btree (card_id);


--
-- Name: notification_comment_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_comment_id_index ON public.notification USING btree (comment_id);


--
-- Name: notification_creator_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_creator_user_id_index ON public.notification USING btree (creator_user_id);


--
-- Name: notification_is_read_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_is_read_index ON public.notification USING btree (is_read);


--
-- Name: notification_service_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_board_id_index ON public.notification_service USING btree (board_id);


--
-- Name: notification_service_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_service_user_id_index ON public.notification_service USING btree (user_id);


--
-- Name: notification_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_user_id_index ON public.notification USING btree (user_id);


--
-- Name: project_favorite_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_favorite_user_id_index ON public.project_favorite USING btree (user_id);


--
-- Name: project_manager_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_manager_user_id_index ON public.project_manager USING btree (user_id);


--
-- Name: project_owner_project_manager_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX project_owner_project_manager_id_index ON public.project USING btree (owner_project_manager_id);


--
-- Name: session_remote_address_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_remote_address_index ON public.session USING btree (remote_address);


--
-- Name: session_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX session_user_id_index ON public.session USING btree (user_id);


--
-- Name: task_assignee_user_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_assignee_user_id_index ON public.task USING btree (assignee_user_id);


--
-- Name: task_linked_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_linked_card_id_index ON public.task USING btree (linked_card_id);


--
-- Name: task_list_card_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_card_id_index ON public.task_list USING btree (card_id);


--
-- Name: task_list_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_list_position_index ON public.task_list USING btree ("position");


--
-- Name: task_position_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_position_index ON public.task USING btree ("position");


--
-- Name: task_task_list_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX task_task_list_id_index ON public.task USING btree (task_list_id);


--
-- Name: uploaded_file_references_total_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX uploaded_file_references_total_index ON public.uploaded_file USING btree (references_total);


--
-- Name: uploaded_file_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX uploaded_file_type_index ON public.uploaded_file USING btree (type);


--
-- Name: user_account_is_deactivated_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_is_deactivated_index ON public.user_account USING btree (is_deactivated);


--
-- Name: user_account_role_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_role_index ON public.user_account USING btree (role);


--
-- Name: user_account_username_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_account_username_index ON public.user_account USING btree (username);


--
-- Name: webhook_board_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhook_board_id_index ON public.webhook USING btree (board_id);


--
-- PostgreSQL database dump complete
--

\unrestrict vAn3r3halAfJQnFpgEGG8C0fChVaVxZsDA2eT5OOI5dGHhpUybHzK81n6WUFjOa

